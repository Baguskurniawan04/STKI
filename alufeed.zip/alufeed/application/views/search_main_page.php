<!DOCTYPE html>
<html lang="en">
<head>
  <title>CARI IN</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  
  <style type="text/css">
    body {
    }
      .ikimargin {margin: 30px;}
.ikipadding {padding: 20px;background: white;}

/* IKI H1 TEXT-ALIGN CENTER */
h1 {
  text-align: center;
  background: black;
  margin-bottom: 20px;
  padding: 10px 30px;
  color: white;display:inline-block;border-radius:10px;
}
h1 span {
  background: #ffba42;
  padding: 10px;
  border-radius: 10px;
  display: inline-block;display:inline-block;margin-left:20px;
}

/* H2 TAK GAWE MARGIN AUTO */

h2 {
  padding: 10px;
  width: 200px;
  background: #ddd;
  margin: 0 auto; 
}

h3{
  color: white;
  background: black;
  text-align: center;
  padding: 10px;
  width: 150px;
  border-radius: 10px;
  margin: 20px auto 0 auto;
  font-size: 20px;
}

h3 span{
  background: #ffba42;
  padding: 10px;
  border-radius: 10px;
  display: inline-block;
}
  </style>
  
</head>
<body>
<div class="container" style="margin-top: 200px; margin-bottom: 200px;">

 <div class="ikimargin">
    <div class="ikipadding">
      <center>
          <h1>
            CARI<span>IN</span>
          </h1>
      </center>
      <!--<h2>-->
      <!--  <span>A</span> Agus Hub-->
      <!--</h2>-->
      <!--<h3>Search<span>Hub</span>-->
      <!--</h3>-->
    </div>
  </div>

<form action="<?php echo base_url() . 'search'; ?>" method="GET">
<div class="form-group">
    <label for="q">Kata Kunci:</label>
    <input type="text" class="form-control" placeholder="Masukkan kata kunci pencarian..." name="q" id="q" value="" required>
</div>
<button type="submit" class="btn btn-success">Cari</button> <button type="button" name="upload_file_btn" id="upload_file_btn" class="btn btn-primary">Upload PDF</button>
</form>
</div>
<script type="text/javascript">
$(document).ready(function(){
$('#upload_file_btn').click(function(){
window.location.href = '<?php echo base_url() . 'upload_page'; ?>';
});
});
</script>
</body>
</html>