<!DOCTYPE html>
<html lang="en">
<head>
  <title>CARI IN</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container" style="margin-top: 100px; margin-bottom: 100px;">
  <h2>Upload Form PDF</h2>
  <form action="upload" method="POST" enctype="multipart/form-data">
    <div class="form-group">
      <label for="file_dokumen">Cari Dokumen PDF:</label>
      <input type="file" class="form-control" id="file_dokumen" placeholder="Enter email" name="file_dokumen" required>
    </div>
    <button type="submit" class="btn btn-success">Submit</button> 
    <button type="button" name="cari_pdf_btn" id="cari_pdf_btn" class="btn btn-primary">Cari PDF</button>
  </form><br>
  <?php
  if($this->session->flashdata('upload_message_error') != "")
  {
    echo '<h3>' . $this->session->flashdata('upload_message_error') . '</h3>';
  }

  if($this->session->flashdata('upload_message') != "")
  {
    $getArraynya = $this->session->flashdata('upload_message');
    //var_dump($getArraynya);

    $titlenya = $getArraynya['title'][0];
    $authornya = $getArraynya['author'][0];
    $producernya = $getArraynya['producer'][0];
    $creatornya = $getArraynya['creator'][0];

    if($titlenya == "")
    {
      $titlenya = "-";
    }

    if($authornya == "")
    {
      $authornya = "-";
    }

    if($producernya == "")
    {
      $producernya = "-";
    }

    if($creatornya == "")
    {
      $creatornya = "-";
    }

    echo '<h3>Hasil Output Upload:</h3>';

    echo '<div class="table-responsive">
    <table class="table table-bordered">
      <thead>
        <tr>
          <th>Nama</th>
          <th>Format</th>
          <th>Ukuran</th>
          <th>Judul</th>
          <th>Author</th>
          <th>Producer</th>
          <th>Creator</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>' . $getArraynya['file_name'] . '</td>
          <td>' . $getArraynya['file_ext'] . '</td>
          <td>' . $getArraynya['file_size'] . ' KB' . '</td>
          <td>' . $titlenya . '</td>
          <td>' . $authornya . '</td>
          <td>' . $producernya . '</td>
          <td>' . $creatornya . '</td>
        </tr>
      </tbody>
    </table>
  </div>
</div>';
  }
  ?>
</div>
<script type="text/javascript">
$(document).ready(function(){
$('#cari_pdf_btn').click(function(){
window.location.href = '<?php echo base_url() . 'index.php'; ?>';
});
});
</script>
</body>
</html>